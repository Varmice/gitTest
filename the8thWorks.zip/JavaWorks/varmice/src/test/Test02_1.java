package test;
//不使用Boolean找质数

public class Test02_1 {
    public static void main(String[] args) {

        int count = 0;
        for (int i = 101; i <= 200; i++) {
            for (int j = 2; j < i; j++) {
                if (i % j == 0){
                    break;
                }
                if (j == i - 1){
                    //System.out.println(i);
                    count ++;
                }


            }
            
        }
        System.out.println(count);
        
        
    }
}
