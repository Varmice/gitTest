package the8thWorks;
//使用String方法
public class StringDemo {
    public static void main(String[] args) {
        String str = "Hello, World!";

        int length = str.length();
        char character = str.charAt(1);
        String subStr = str.substring(7, 12);
        String concatStr = str.concat(" Goodbye!");
        String lowerCase = str.toLowerCase();
        String upperCase = str.toUpperCase();
        String trimmed = str.trim();
        boolean areEqual = str.equals("Hello, World!");
        boolean containsWorld = str.contains("World");

        System.out.println("原字符串: " + str);
        System.out.println("长度: " + length);
        System.out.println("字符索引1: " + character);
        System.out.println("子字符串: " + subStr);
        System.out.println("连接字符串: " + concatStr);
        System.out.println("小写: " + lowerCase);
        System.out.println("大写: " + upperCase);
        System.out.println("修剪后的字符串: " + trimmed);
        System.out.println("是否相等: " + areEqual);
        System.out.println("包含 'World': " + containsWorld);
    }
}
