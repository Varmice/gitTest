package the6thWorks;
//通过打印的方式观察"/t"的长度


public class Separator_t {
    public static void main(String[] args) {
        System.out.println("12345678901234567890");
        System.out.println("\t" + "00000000000");
        System.out.println("0000" + "\t" + "0000000000" );

        System.out.println("由上述打印可知't'的长度为4");







    }

}
