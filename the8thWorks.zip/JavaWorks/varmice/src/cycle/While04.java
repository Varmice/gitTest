package cycle;
/*
循环中continue、break的使用
 */
public class While04 {
    public static void main(String[] args) {
        for (int i = 1; i <= 5; i++) {
            //第三个包子里面有虫子，所以跳过
            if (i == 3){
                continue;
            }


            System.out.println("小猫咪在吃第 " + i + " 个包子");
        }



    }
}
