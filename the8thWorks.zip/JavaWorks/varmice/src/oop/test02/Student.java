package oop.test02;

public class Student {
    String name;
    int age;

    public void study(){
        System.out.println("Study!!");
    }
}
