package the5thWorks;

import java.util.Scanner;
import java.util.Arrays;

public class SortNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //System.out.println("请输入3个整数，用空格分隔：");
        String input = scanner.nextLine();

        // 使用空格分割输入字符串，并将分割后的数字存入一个整数数组
        String[] numbers = input.split(" ");
        int[] intArray = new int[3];
        for (int i = 0; i < 3; i++) {
            intArray[i] = Integer.parseInt(numbers[i]);
        }

        // 使用Arrays.sort()方法对整数数组进行排序
        Arrays.sort(intArray);

        // 输出排序后的结果
        //System.out.print("从小到大排序后的整数：");
        for (int i = 0; i < 3; i++) {
            System.out.print(intArray[i] + " ");
        }

        scanner.close();
    }
}
