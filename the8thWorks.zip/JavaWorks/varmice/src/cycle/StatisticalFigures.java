package cycle;

import java.util.Scanner;

public class StatisticalFigures {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入第一个整数");
        int a = sc.nextInt();
        System.out.println("请输入第二个整数");
        int b = sc.nextInt();
        System.out.println();

        /*if (b > a){
            int t = a;
            a = b;
            b = t;
        }*/
        int count = 0;
        for (int i = a; i <= b; i++) {
            if (i % 3 == 0 && i % 5 == 0){
                count++;
                //System.out.println(i);
            }


        }
        System.out.println(count);




    }
}
