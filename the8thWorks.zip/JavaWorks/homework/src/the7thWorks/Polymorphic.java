package the7thWorks;
/*创建Polymorphic类作为主类，内有主函数；

创建Animal类作为父类，包含一个speak方法。

创建一个Cat类继承于Animal类，重写speak方法；此外创建一个Dog类继承于Animal，同样重写了speak方法。*/
class Animal {
    public void speak() {
        System.out.println("Animal speaks");
    }
}

class Cat1 extends Animal {
    @Override
    public void speak() {
        System.out.println("miao");
    }
}

class Dog extends Animal {
    @Override
    public void speak() {
        System.out.println("wang");
    }
}

public class Polymorphic {
    public static void testAnimal(Animal animal) {
        animal.speak();
    }

    public static void main(String[] args) {
        Animal cat = new Cat1();
        testAnimal(cat);
        Animal dog = new Dog();
        testAnimal(dog);
    }
}
