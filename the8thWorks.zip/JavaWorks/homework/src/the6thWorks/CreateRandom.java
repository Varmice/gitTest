package the6thWorks;
//生成60到100随机数，给学生成绩赋值

import java.util.Random;

public class CreateRandom {
    public static void main(String[] args) {
        /*int[] a = {1, 2, 3, 4, 5};
        a[1] = (int) (Math.random() * (100 - 60 + 1) + 60);*/
        Random random = new Random();
        int[] arr = new int[60];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = random.nextInt(100 - 60) + 60;
        }

        System.out.println("随机整数数组为：");
        for (int i = 0; i < arr.length; i++) {

            if (i % 8 == 0){
                System.out.println();
            }
            System.out.print(arr[i] + " ");
        }

        int Min = arr[0];
        int Max = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < Min){
                Min = arr[i];
            }
            if (arr[i] > Max){
                Max = arr[i];
            }
        }
        System.out.println();
        System.out.println("该随机数中最大值为：" + Max);
        System.out.println("该随机数中最小值为：" + Min);

        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += i;
        }

        System.out.println("该随机数的和为：" + sum);
    }
}
