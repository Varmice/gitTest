package oop.test01;

public class StudentTest {
    public static void main(String[] args) {
        Student s = new Student("zhangsan",20);

//        s.setName("Tome");
//        s.setAge(18);

       /* String N = s.getName();
        int A = s.getAge();*/

        System.out.println(s.getName());
        System.out.println(s.getAge());

        s.PlayGame();
        s.Dance();
    }
}
