package chapter02;

public class Example07 {
    public static void main(String[] args) {
        int x = 5;
        if(x < 10){
            x++;
        }
        System.out.println("x = "+x);
    }
}
