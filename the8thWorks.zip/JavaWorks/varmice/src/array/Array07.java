package array;
//打乱数组中的数据

import java.util.Random;

public class Array07 {

    public static void main(String[] args) {
        //创建随机数与其交换
        Random r = new Random();
        System.out.println("数组元数据：");
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");

        }
        System.out.println();

        //System.out.println(arr.length);
        for (int i = 0; i < arr.length; i++) {
            int arrindex = r.nextInt(arr.length);
            int temp = arr[i];
            arr[i] = arr[arrindex];
            arr[arrindex] = temp;
        }

        System.out.println();
        System.out.println("数组交换后数据：");

        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");

        }


    }
}
