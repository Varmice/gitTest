package test;
//买飞机票(使用方法优化代码，提高代码复用率)
import java.util.Scanner;

/*
机票价格按照淡季旺季，头等舱和经济舱收费。
键盘录入机票原价，月份和头等舱还是经济舱。
按照以下规则计算机票价格：
旺季（5-10月份）：头等舱9折，经济舱8.5折；
淡季（11月到来年4月）：头等舱7折，经济舱6.5折；
 */
public class Test01_1 {
    public static void main(String[] args) {

        Double ticket;
        int month;
        int house;

        Scanner sc = new Scanner(System.in);
        System.out.println("请输入机票原价，购买月份以及舱型(头等舱：0，经济舱：1)，并将其用空格隔开");
        ticket = sc.nextDouble();
        month = sc.nextInt();
        house = sc.nextInt();
        //System.out.print("机票原价；" + money + " 购买月份:" + month + " 购买舱型:" + house);

        if (month >=5 && month <=10){
            ticket = getPrice(ticket,house,0.9,0.85);
            System.out.println(ticket);

        }
        else if((month >= 11 && month <= 12) ||(month >= 1 && month <= 4)){

            ticket = getPrice(ticket,house,0.7,0.65);
            System.out.println(ticket);
        }
        else{
            System.out.println("您输入的月份有误！！！");
        }
    }


    public static Double getPrice(Double ticket,int house,Double v0,Double v1){
        if (house == 0){
            ticket = ticket * v0;
        }
        else if (house == 1){
            ticket = ticket * v1;
        }
        else{
            System.out.println("您输入的舱型有误，请重新输入");
        }
        return ticket;

    }





}

