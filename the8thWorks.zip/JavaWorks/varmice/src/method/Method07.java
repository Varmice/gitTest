package method;
//定义一个方法判断数组中的某一个数是否存在，将结果返回给调用处

import java.util.Scanner;

public class Method07 {
    public static void main(String[] args) {
        int[] arr = {1,3,5,7,9,11};
        System.out.println("请输入一个数：");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        boolean answer = judge(arr,num);
        System.out.println(answer);

    }


    public static boolean judge(int[] arr,int num){

        for (int i = 0; i < arr.length; i++) {
            if (num == arr[i]){
                return true;
            }
        }
        return false;

    }


}
