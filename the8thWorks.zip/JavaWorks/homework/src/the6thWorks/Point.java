package the6thWorks;
/*
设计一个Point类，私有成员变量pointX,pointY

公有成员函数void set(int x,int y);功能是设置坐标

公有成员函数void display();功能是显示坐标。
 */
public class Point {
    private int pointX;
    private int pointY;

    public void set(int x, int y) {
        pointX = x;
        pointY = y;
    }

    public void display() {
        System.out.println(pointX);
        System.out.println(pointY);
    }

    public static void main(String[] args) {
        Point point = new Point(); // 创建Point对象

        point.set(1, 2); // 设置坐标
        point.display(); // 显示坐标
    }
}
