package oop.test02;

public class User {
    //成员属性
    private String username;
    private String password;
    private String email;
    private String gender;
    private int age;

    //空参
    public User(){}

    //带全部参数
    public User(String username,String password,String email,String gender,int age){
        this.username = username;
        this.password = password;
        this.email = email;
        this.gender = gender;
        this.age = age;
    }

    //get 和 set 方法
    public void setUsername(){
        this.username = username;
    }

    public String getUsername(){
        return username;
    }


}
