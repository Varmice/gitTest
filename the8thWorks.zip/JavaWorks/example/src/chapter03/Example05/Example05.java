package chapter03.Example05;/*
package com.itheima;


class Student{
    public Student() {
        System.out.println("调用了无参构造方法");
    }
}
public class Example05 {
    public static void main(String[] args) {
        System.out.println("声明对象...");
        Student stu = null;           		//声明对象
        System.out.println("实例化对象...");
        stu = new Student();     			//实例化对象
    }
}

*/
