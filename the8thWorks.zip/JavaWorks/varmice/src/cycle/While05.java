package cycle;
//利用循环写一个1-100中逢7就过的小游戏
public class While05 {
    public static void main(String[] args) {

        int i = 0;
        while (i < 100){
            i++;
            if (i % 7 == 0 || i / 10 == 7|| i % 10 == 7){
                System.out.println("过");
            }
            else{
                System.out.println(i);
            }

        }

    }
}
