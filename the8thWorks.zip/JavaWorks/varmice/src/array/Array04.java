package array;
//定义一个数组，如果该数组为奇数就扩大至两倍，如果是偶数就缩小至二分之一
public class Array04 {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8,9,10};

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] % 2 != 0){
                arr[i] *= 2;
            }
            else{
                arr[i] /= 2;
            }
            System.out.println(arr[i]);

        }




    }
}
