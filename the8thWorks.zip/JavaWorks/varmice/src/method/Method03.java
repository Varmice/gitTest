package method;
//定义一个方法输出长方形周长


import java.util.Scanner;

public class Method03 {
    public static void perimeter(int a , int b ){
        int c = (a + b) * 2;
        System.out.println("长方形周长是：" + c);

    }
    public static void main(String[] args) {
        System.out.println("请输入整型的长方形的宽和高");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b =sc.nextInt();
        perimeter( a , b);

    }
}
