package the6thWorks;
//插入排序
public class InsertionSort {
    public static void main(String[] args) {
        int[] arr = {164, 4, 132, 22, 11};
        insertionSort(arr);

        System.out.println("Sorted array:");
        for (int value : arr) {
            System.out.print(value + " ");
        }
    }

    public static void insertionSort(int[] arr) {
        int n = arr.length;

        for (int i = 1; i < n; i++) {
            int currentElement = arr[i];
            int j = i - 1;

            // 移动已排序部分中的元素，为当前元素腾出位置
            while (j >= 0 && arr[j] > currentElement) {
                arr[j + 1] = arr[j];
                j--;
            }

            // 插入当前元素到正确的位置
            arr[j + 1] = currentElement;
        }
    }
}
