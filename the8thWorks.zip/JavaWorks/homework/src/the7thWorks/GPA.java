package the7thWorks;
//根据平均绩点，计算是否可以顺利毕业

import java.util.Scanner;

//马克思主义基本原理  3'
//新生入学教育    1'
//操作系统原理    3'
//Web前端设计   3'
//面向对象程序设计(Java)    5'
//离散数学  3'
//计算机组织与体系结构    2.5'
//面向对象程序设计实践    3'
//中国近现代史纲要  3   '
//大学生劳动实践锻炼	    1'
public class GPA {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int length;
        System.out.println("请输入你有几门课程：");
        length = sc.nextInt();
        System.out.println("请输入您每门科目的学分并将其用空格隔开：");
        Double[] arr = new Double[length];
        for (int i = 0; i < length; i++) {
            arr[i] = sc.nextDouble();
        }
        Double sum = 0.0;
        for (int i = 0; i < length; i++) {

            sum += arr[i];
            //System.out.print(arr[i] + " ");

        }
        //System.out.print("您的总成绩为：");
        //System.out.print(sum);
        //System.out.println();
        Double averageGPA = (sum / length);
        System.out.println("您的平均成绩为：");
        System.out.println(averageGPA);


        if (averageGPA >= 2.0) {
            System.out.println("恭喜，你可以毕业！");
        } else {
            System.out.println("很抱歉，你的平均绩点不足2.0，无法毕业。");
        }

    }
}
