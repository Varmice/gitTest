package chapter02;

public class Example25 {
    public static void main(String[] args) {
        int[] arr = new int[4];                 // 定义一个长度为4的数组
        System.out.println("arr[0]=" + arr[4]); // 通过索引4访问数组元素
    }
}
