package the5thWorks;

import java.util.Scanner;

public class Equation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //System.out.print("请输入一元二次方程的系数 a, b, c（用空格分隔）：");
        double a = scanner.nextDouble();
        double b = scanner.nextDouble();
        double c = scanner.nextDouble();

        if (a == 0) {
            System.out.println("not equation");
        } else {
            double discriminant = b * b - 4 * a * c;

            if (discriminant > 0) {
                double x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
                double x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
                System.out.println("x1=" + x1);
                System.out.println("x2=" + x2);
            } else if (discriminant == 0) {
                double x1 = -b / (2 * a);
                System.out.println("x1=x2=" + x1);
            } else {
                System.out.println("no real roots");
            }
        }

        scanner.close();
    }
}
