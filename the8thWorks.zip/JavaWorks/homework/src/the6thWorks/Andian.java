package the6thWorks;
//给定一个二维数组，里面存储一个4*4的矩阵，输出鞍点数值及其位置
public class Andian {
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12},
                {13, 14, 15, 16}
        };

        findPoints(matrix);
    }

    public static void findPoints(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int currentElement = matrix[i][j];
                boolean isPoint = true;

                // Check if current element is the maximum in its row
                for (int k = 0; k < cols; k++) {
                    if (matrix[i][j] < matrix[i][k]) {
                        isPoint = false;
                        break;
                    }
                }

                // Check if current element is the minimum in its column
                for (int k = 0; k < rows; k++) {
                    if (matrix[i][j] > matrix[k][j]) {
                        isPoint = false;
                        break;
                    }
                }

                if (isPoint) {
                    System.out.println("鞍点数位置为：(" + i + ", " + j + ") 其值为： " + currentElement);
                }
            }
        }
    }
}
