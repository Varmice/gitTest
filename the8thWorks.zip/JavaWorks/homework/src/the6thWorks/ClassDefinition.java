package the6thWorks;
//类的定义，输出name、sex、age..

class student{
    String name ;
    String sex;
    int age;
    void read(){
        System.out.println("My name is " + name +"." + "I am " + age + " years old." + "I am a " + sex);
    }
}

public class ClassDefinition {
    public static void main(String[] args) {
        student stu = new student();
        stu.name = "Varmice";
        stu.sex = "boy";
        stu.age = 18;
        stu.read();


    }
}
