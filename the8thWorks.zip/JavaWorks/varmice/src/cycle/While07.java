package cycle;
//键盘录入一个整型数据，判断其是否是一个质数

//代码优化：如何求100000是否为质数需要循环近100000次，如果从其平方根开始求，可以大大缩减
//例如100000平方根可以缩减到300多次
import java.util.Scanner;

public class While07 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入一个整型数据：");
        int num = sc.nextInt();

        boolean flag = true;

        for (int i = 2; i < num; i++) {
            if (num % i == 0){
                //System.out.println(num + " 不是一个质数");
                flag = false;
                break;
            }
            //这里不能使用else，可以使用一个Boolean类型解决问题
        }

        if (flag){
            System.out.println(num + " 不是一个质数");
        }
        else{
            System.out.println(num + " 是一个质数");
        }



    }
}
