package the5thWorks;
//给定三个数字，从大到小依次输出
import java.util.Scanner;

//给定三个数字，从大到小依次输出
public class SwapNum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("plz input three nums");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        if (a>b){
            if (c >a){
                System.out.println(c + ">" + a + ">" + b);
            }
            else if(a > c&& c > b){
                System.out.println(a + ">" + c + ">" + b);
            }
            else{
                System.out.println(a + ">" + b + ">" + c);
            }
        }
        else{
            if (c >b){
                System.out.println(c + ">" + b + ">" + a);
            }
            else if(b > c&& c > a){
                System.out.println(b + ">" + c + ">" + a);
            }
            else{
                System.out.println(b + ">" + a + ">" + c);
            }
        }
    }
}
