package the6thWorks;
//设计一个Box类，求3个长方体的体积
public class Box {
    private int length;
    private int width;
    private int height;

    // 设置成员变量的方法
    public void set(int l, int w, int h) {
        length = l;
        width = w;
        height = h;
    }

    // 计算和打印长方体体积的方法
    public void volume() {
        int volume = length * width * height;
        //System.out.println("长方体的体积为: " + volume);
        System.out.println(volume);
    }

    public static void main(String[] args) {
        Box box = new Box(); // 创建Box对象
        box.set(1, 2, 3); // 设置长宽高
        box.volume(); // 计算和打印体积
    }
}

