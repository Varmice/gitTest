package method;
//方法必须写在class的里面，main的外面

/*
    1.我要干嘛
    2.我需要什么
    3.是否需要返回值
 */
public class Method01 {

    public static void temp(){
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");

    }
    public static void main(String[] args) {
        temp();
        temp();
    }



}
