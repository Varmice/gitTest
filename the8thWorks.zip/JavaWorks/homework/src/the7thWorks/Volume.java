package the7thWorks;
//编写一个程序计算出圆柱体的体积。
class Shape {
    protected double radius;

    public Shape(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
}

class Cylinder extends Shape {
    private double height;

    public Cylinder(double radius, double height) {
        super(radius);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double volume() {
        return 3.14 * getRadius() * getRadius() * height;
    }
}

public class Volume {
    public static void main(String[] args) {
        Cylinder c = new Cylinder(1, 1);
        System.out.println(c.volume());
    }
}
