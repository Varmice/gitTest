package oop.test02;

public class StudentTest {
    public static void main(String[] args) {
        Student s1 = new Student();
        s1.name = "+++++";
        System.out.println("s1.name = " + s1.name);
        Student s2 = new Student();
        s2.name = "****";



    }

}
