package test;
//买飞机票
import java.util.Scanner;

/*
机票价格按照淡季旺季，头等舱和经济舱收费。
键盘录入机票原价，月份和头等舱还是经济舱。
按照以下规则计算机票价格：
旺季（5-10月份）：头等舱9折，经济舱8.5折；
淡季（11月到来年4月）：头等舱7折，经济舱6.5折；
 */
public class Test01 {
    public static void main(String[] args) {

        Double money;
        int month;
        int house;

        Scanner sc = new Scanner(System.in);
        System.out.println("请输入机票原价，购买月份以及舱型(头等舱：0，经济舱：1r)，并将其用空格隔开");
        money = sc.nextDouble();
        month = sc.nextInt();
        house = sc.nextInt();
        //System.out.print("机票原价；" + money + " 购买月份:" + month + " 购买舱型:" + house);

        if (month >=5 && month <=10){
            if (house == 0){
                System.out.println("机票价格为：" + money * 0.9);
            }
            else if (house == 1){
                System.out.println("机票价格为：" + money * 0.85);
            }
            else{
                System.out.println("您输入的舱型有误，请重新输入");
            }

        }
        else if((month >= 11 && month <= 12) ||(month >= 1 && month <= 4)){

            if (house == 0){
                System.out.println("机票价格为：" + money * 0.7);
            }
            else if (house == 1){
                System.out.println("机票价格为：" + money * 0.65);
            }
            else{
                System.out.println("您输入的舱型有误，请重新输入");
            }
        }
        else{
            System.out.println("您输入的月份有误！！！");
        }
    }
}
