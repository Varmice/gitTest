package the8thWorks;
//计算一百天后日期
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalDate {
    public static void main(String[] args) {
        // 创建一个Calendar对象并设置日期为2021年11月11日
        Calendar calendar = Calendar.getInstance();
        calendar.set(2021, Calendar.NOVEMBER, 11);

        // 使用add方法计算100天后的日期
        calendar.add(Calendar.DAY_OF_YEAR, 100);

        // 获取计算后的日期对象
        Date date = calendar.getTime();

        // 创建SimpleDateFormat对象以格式化日期
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // 使用SimpleDateFormat格式化日期，并将结果打印出来
        String formattedDate = dateFormat.format(date);
        System.out.println(formattedDate);
    }
}

