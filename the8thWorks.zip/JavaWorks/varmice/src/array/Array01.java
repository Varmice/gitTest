package array;
//数组的定义

public class Array01 {
    public static void main(String[] args) {
        int[] arr1 = {1,2,3,4,5};
        String[] arr2 = {"zhangsan","lisi","wangwu"};

        for (int i = 0; i < arr1.length; i++) {
            System.out.println(arr1[i]);
        }
        for (int i = 0; i < arr2.length; i++) {
            System.out.println(arr2[i]);
        }
    }
}
