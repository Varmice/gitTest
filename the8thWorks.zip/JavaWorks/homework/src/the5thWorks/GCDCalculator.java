package the5thWorks;

import java.util.Scanner;

public class GCDCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //System.out.print("请输入两个正整数（用空格分隔）：");
        int m = scanner.nextInt();
        int n = scanner.nextInt();

        int gcd = calculateGCD(m, n);

        System.out.println(gcd);

        scanner.close();
    }

    // 使用辗转相除法计算最大公约数
    public static int calculateGCD(int m, int n) {
        while (n != 0) {
            int temp = m % n;
            m = n;
            n = temp;
        }
        return m;
    }
}
