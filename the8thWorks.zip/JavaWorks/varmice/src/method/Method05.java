package method;
//设计一个方法求数组最大值

import java.util.Scanner;

public class Method05 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //System.out.println("请输入一个数组");
        int[] arr = { 2 , 3 , 44 ,55 ,6};
        int Max = getMax(arr);
        System.out.println(Max);
    }
    public static int getMax(int arr[]){
        int Max = arr[0];
        for (int i = 1; i < arr.length; i++) {
            if(arr[i] > Max){
                Max = arr[i];
            }
        }
        return Max;

    }


}
