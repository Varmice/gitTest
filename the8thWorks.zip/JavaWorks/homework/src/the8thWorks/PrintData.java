package the8thWorks;
//利用java日期相关知识，查找并打印出2019年每个月第一个周日的日期，日期形式为“yyyy-MM-dd”
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class PrintData {
    public static void main(String[] args) {
        int year = 2019;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        for (int month = 0; month < 12; month++) {
            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month, 1);

            while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }

            System.out.println(dateFormat.format(calendar.getTime()));
        }
    }
}

