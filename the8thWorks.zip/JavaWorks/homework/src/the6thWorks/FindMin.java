package the6thWorks;
//找到数组中最小值及其下标并打印

public class FindMin {
    public static void main(String[] args) {

        int[] arr = {4,3,5,6,7,8,2,1,9};
        int pos = 0;
        int min = arr[0];
        for (int i = 0; i < arr.length; i++) {
            if (min > arr[i]){
                pos = i;
                min = arr[i];
            }
        }
        System.out.println(min + "\t" + pos);


    }
}
