package cycle;

public class Switch {
    public static void main(String[] args) {
        int num = 1;
        /*switch (num){
            case 1:
                System.out.println("一");
                break;
            case 2:
                System.out.println("二");
                break;
            case 3:
                System.out.println("三");
                break;
            default:
                System.out.println("None");
                break;*/
        switch (num){
            //如果输出语句只有一行，则大括号可以省略
            case 1 -> System.out.println("一一");
            case 2 -> {
                System.out.println("二二");
            }
            case 3 -> {
                System.out.println("三三");
            }
            default -> {
                System.out.println("None");
            }




        }
    }
}
