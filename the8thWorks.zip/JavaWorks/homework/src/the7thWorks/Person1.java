package the7thWorks;
//编辑Person类，有两个double类型的私有成员变量weight、height，需要为每个成员变量设计get/set方法
public class Person1 {
    private double weight;
    private double height;

    public Person1(double weight, double height) {
        setWeight(weight);
        setHeight(height);
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        if (weight < 0 || weight > 400) {
            this.weight = 70.0;
        } else {
            this.weight = weight;
        }
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        if (height < 0 || height > 300) {
            this.height = 170.0;
        } else {
            this.height = height;
        }
    }

    public static void main(String[] args) {
        Person1 p1 = new Person1(-100, 165.5);
        System.out.println(p1.getWeight());
        System.out.println(p1.getHeight());

        Person1 p2 = new Person1(65.5, 400);
        System.out.println(p2.getWeight());
        System.out.println(p2.getHeight());
    }
}
