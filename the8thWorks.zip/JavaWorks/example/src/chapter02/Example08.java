package chapter02;

public class Example08 {
    public static void main(String[] args) {
        int num = 19;
        if(num % 2 == 0){
            //判断条件成立，num呗2整除
            System.out.println("num是一个偶数");
        }else{
            System.out.println("num是一个奇数");
        }

    }
}
