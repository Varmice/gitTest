package the6thWorks;
//求给定数组的平均值
public class ArrAvg {
    public static void main(String[] args) {
        int[] numbers = {89, 78, 85, 67, 92, 74, 99, 81};

        int sum = 0;
        for (int number : numbers) {
            sum += number;
        }

        double average = (double) sum / numbers.length;

        System.out.print(numbers[0]);
        for (int i = 1; i < numbers.length; i++) {
            System.out.print(" " + numbers[i]);
        }
        System.out.println(); // 换行

        System.out.println(average); // 输出平均值
    }
}

