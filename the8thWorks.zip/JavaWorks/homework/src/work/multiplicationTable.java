package work;

public class multiplicationTable {
    public static void main(String[] args) {
        //九九乘法表的两种方法
        for (int i = 1; i <= 9;i++){
            for (int j = 1; j <= i;j++){
                //第一种方法
                System.out.print(j + "*" + i + "=" + j * i + "\t");
                //第二种方法
                //System.out.println("%d*%d=%-3d",j,i,i*j);
            }
            System.out.println();
        }
    }
}
