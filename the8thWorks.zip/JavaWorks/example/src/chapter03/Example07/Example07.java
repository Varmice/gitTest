package chapter03.Example07;/*
package com.itheima;

class Student{
    private String name;
    private int age;
    public Student() { }
    public Student(String n) {
        name = n;
        System.out.println("调用了一个参数的构造方法");
    }
    public Student(String n,int a) {
        name = n;
        age = a;
        System.out.println("调用了两个参数的构造方法");
    }
    public void read(){
        System.out.println("我是:"+name+",年龄:"+age);
    }
}
public class Example07 {
    public static void main(String[] args) {
        Student stu1 = new Student("张三");
        Student stu2 = new Student("张三",18);   // 实例化Student对象
        stu1.read();
        stu2.read();
    }
}
*/
