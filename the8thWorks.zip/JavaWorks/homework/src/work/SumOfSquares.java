package work;
//1^2+2^2+3^2+……，当和大于1000时停止，输出和及最后加的是那个数的平方
public class SumOfSquares {
    public static void main(String[] args) {
        int n = 1;
        int sum = 0;
        int lastNumber = 0;

        while (true) {
            int square = n * n;
            sum += square;

            if (sum > 1000) {
                break;
            }

            lastNumber = n;
            n++;
        }

        System.out.println("和大于1000时，最后加的是 " + lastNumber + " 的平方");
        System.out.println("总和为 " + sum);
    }
}