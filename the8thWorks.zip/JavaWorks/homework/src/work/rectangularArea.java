package work;

import java.util.Scanner;

public class rectangularArea {
    //求矩形面积
    public static void main(String[] args) {
        System.out.println("请输入矩形的宽：");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        System.out.println("请输入矩形的长：");
        int b = sc.nextInt();

        int area = a * b;

        System.out.println("矩形的面积为：" + area);

    }
}
