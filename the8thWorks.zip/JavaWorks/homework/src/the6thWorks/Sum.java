package the6thWorks;
//1- 999 遍历，如果是奇数就累加
public class Sum {
    public static void main(String[] args) {
        int sum = 0;

        for (int i = 1; i <= 999; i++) {
            if (i % 2 != 0) { // 检查是否是奇数
                sum += i; // 累加奇数
            }
        }

        //System.out.println("1 + 3 + 5 + 7 + ... + 999 的和为: " + sum);
        System.out.println(sum);
    }
}
