
package chapter03.Example08;

class Student{
    int age;
    public Student(int n) {
        age = n;
    }
}
public class Example08 {
    public static void main(String[] args) {
//        Student stu = new Student();
    }
}

