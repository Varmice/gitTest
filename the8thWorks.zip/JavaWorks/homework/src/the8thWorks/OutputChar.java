package the8thWorks;
//输出26个英文字母的子序列
public class OutputChar {
    public static void main(String[] args) {
        String input = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        StringBuilder output = new StringBuilder();

        int step = 1; // 初始步长
        for (int i = 0; i < input.length(); i += step) {
            output.append(input.charAt(i));
            step++; // 增加步长
        }

        System.out.println(output.toString());
    }
}

