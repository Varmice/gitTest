package work;

import java.util.Scanner;

public class triangleArea {
    //根据三角形三边长求面积
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入三角形的一个边a = ");
        int a = sc.nextInt();
        System.out.println("请输入三角形的一个边b = ");
        int b = sc.nextInt();
        System.out.println("请输入三角形的一个边c = ");
        int c = sc.nextInt();

        double s = (a + b + c) / 2;
        double area =  Math.sqrt(s * (s - a) * (s - b) * (s - c));

        if(a + b > c|| a + c > b|| b + c > a){

            System.out.println("三角形的面积为：" + area);

        }

    }
}
