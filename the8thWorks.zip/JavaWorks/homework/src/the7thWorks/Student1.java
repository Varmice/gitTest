package the7thWorks;
//定义一个Student类，要求有name及age两个属性，
// 根据这两个属性编写构造方法，再定义一个show方法，输出其相关信息
public class Student1 {
    private String name;
    private int age;

    public Student1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void show() {
        System.out.println("my name is " + name + ",i am " + age + " years old.");
    }

    public static void main(String[] args) {
        Student1 s = new Student1("wang xio ming", 19);
        s.show();
    }
}

