package work;
//年增长率为6%，多少年后翻一番
public class DoublingTimeCalculator {
    public static void main(String[] args) {
        double initialAmount = 1.0; // 初始金额
        double growthRate = 0.06;  // 年增长率
        double targetAmount = initialAmount * 2; // 目标金额，即翻一番的金额
        int years = 0; // 初始年数

        while (initialAmount < targetAmount) {
            initialAmount *= (1 + growthRate); // 每年增长6%
            years++;
        }

        System.out.println("年增长率为6%，需要 " + years + " 年才能翻一番。");
    }
}