package the6thWorks;
//冒泡排序，倒序输出
public class BubbleSort2 {
    public static void main(String[] args) {
        int[] numbers = {89, 78, 85, 67, 92, 74};

        // 冒泡排序算法
        for (int i = 0; i < numbers.length - 1; i++) {
            for (int j = 0; j < numbers.length - 1 - i; j++) {
                if (numbers[j] < numbers[j + 1]) {
                    // 交换元素
                    int temp = numbers[j];
                    numbers[j] = numbers[j + 1];
                    numbers[j + 1] = temp;
                }
            }
        }

        // 输出排序后的结果
        System.out.print(numbers[0]);
        for (int i = 1; i < numbers.length; i++) {
            System.out.print(" " + numbers[i]);
        }
        System.out.println(); // 换行
    }
}
