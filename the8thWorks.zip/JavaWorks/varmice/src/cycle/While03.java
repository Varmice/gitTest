package cycle;
/*
    不使用除法、乘法和取模运算来得到商和余数
 */

public class While03 {
    public static void main(String[] args) {

    int i = 100;
    int j = 9;
    int count = 0;

    while (i >= j)
    {
        i -= j ;
        count += 1;
    }

        System.out.println("商为：" + count);
        System.out.println("余数为：" + i);




    }
}
