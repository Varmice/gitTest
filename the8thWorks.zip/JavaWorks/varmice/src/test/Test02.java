package test;

//找质数
/*
判断101-200之间有多少个素数，并打印输出
 */
public class Test02 {
    public static void main(String[] args) {

        for (int i = 101; i <= 200; i++) {
            boolean num = true;
            for (int j = 2; j < i; j++) {
                if (i % j == 0){
                    num = false;
                    break;
                }
            }

            if (num == true){
                System.out.println(i);
            }
        }

    }
}
