package cycle;
//计算折纸次数
public class While01 {
    public static void main(String[] args) {

        int height = 8844430;

        double paper = 0.1;

        int count = 0;

        while (paper < height){
            paper *= 2;
            count++;

        }
        System.out.println(count);














    }
}
