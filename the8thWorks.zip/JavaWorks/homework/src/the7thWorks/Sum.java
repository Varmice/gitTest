package the7thWorks;
//重载sub函数，使得其函数既能接收两个都为int类型的变量，也能接收两个都为double类型的变量
public class Sum {
    public static int sub(int a, int b) {
        return a - b;
    }

    public static double sub(double a, double b) {
        return a - b;
    }

    public static void main(String[] args) {
        int result1 = sub(10, 1);
        double result2 = sub(10.0, 1.0);

        System.out.println(result1);
        System.out.println(result2);
    }
}
