package the6thWorks;
/*
先设计一个名为Rectangle的类表示矩形。这个类包括：

两个名为width和height的double型数据域，分别表示矩形的宽和高。width和height的默认值都为1。

创建矩形类的无参构造方法

一个创建width和height为指定值的矩形类的构造方法

一个名为getArea(）的方法，返回这个矩形的面积

一个名为getPperimeter（）的方法返回这个矩形的周长。

然后，编写一个测试程序，创建两个Rectangle对象，一个矩形对象的宽为4而高为40，另一个矩形的宽为3.5而高为35.9.

按照每个矩形的宽、高、面积和周长的顺序显示。（面积和周长保留一位小数
 */
class Rectangle {
    double width;
    double height;

    // 无参构造方法
    public Rectangle() {
        width = 1.0;
        height = 1.0;
    }

    // 带参数的构造方法
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public double getArea() {
        return width * height;
    }

    public double getPerimeter() {
        return 2 * (width + height);
    }
}

public class TestRectangle {
    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle(4.0, 40.0);
        Rectangle rectangle2 = new Rectangle(3.5, 35.9);

        // 输出矩形1的宽、高、面积、周长
        System.out.println(rectangle1.width);
        System.out.println(rectangle1.height);
        System.out.println(String.format("%.1f", rectangle1.getArea()));
        System.out.println(String.format("%.1f", rectangle1.getPerimeter()));

        // 输出矩形2的宽、高、面积、周长
        System.out.println(rectangle2.width);
        System.out.println(rectangle2.height);
        System.out.println(String.format("%.1f", rectangle2.getArea()));
        System.out.println(String.format("%.1f", rectangle2.getPerimeter()));

    }
}
