package the7thWorks;
//封装
class Person2 {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        } else {
            System.out.println("Invalid name.");
        }
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age >= 0) {
            this.age = age;
        } else {
            System.out.println("Invalid age.");
        }
    }
}

public class Person {
    public static void main(String[] args) {
        Person2 person = new Person2();

        // 使用公有方法设置和获取字段值
        person.setName("Alice");
        person.setAge(30);

        // 尝试直接访问私有字段（将导致编译错误）
        // person.name = "Bob"; // 这是不允许的

        // 使用公有方法获取字段值
        System.out.println("Name: " + person.getName());
        System.out.println("Age: " + person.getAge());
    }
}

