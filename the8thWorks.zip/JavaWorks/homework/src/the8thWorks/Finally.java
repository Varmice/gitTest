package the8thWorks;
//finally的使用方法
public class Finally {
    public static void main(String[] args) {
        try {
            // 一些可能引发异常的代码
            int result = 10 / 0; // 这里会抛出 ArithmeticException
            System.out.println("这句话不会被执行");
        } catch (ArithmeticException e) {
            System.err.println("发生了算术异常: " + e.getMessage());
        } finally {
            System.out.println("这句话总会被执行，无论是否发生异常");
        }
    }
}
