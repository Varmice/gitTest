package the6thWorks;
//给定数组求最大值及其位置
public class Findpos {
    public static void main(String[] args) {
        int[] numbers = {89, 78, 85, 67, 92, 74, 99, 80};

        int max = numbers[0];
        int maxPosition = 0;

        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
                maxPosition = i;
            }
        }

        System.out.print(numbers[0]);
        for (int i = 1; i < numbers.length; i++) {
            System.out.print(" " + numbers[i]);
        }
        System.out.println(); // 换行

        System.out.println(max); // 输出最大值
        System.out.println(maxPosition + 1); // 输出最大值的位置
    }
}

