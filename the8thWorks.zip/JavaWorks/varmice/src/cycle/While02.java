package cycle;
//判断回文数

public class While02 {
    public static void main(String[] args) {

        //Scanner sc = new Scanner(System.in);
        //System.out.println("请输入一个三位数");
        //int num = sc.nextInt();
        int x = 12345;
        int num = 0;
        while (x != 0){
            int i = x % 10;
            x = x / 10;
            num = num * 10 + i;

        }
        System.out.println(num);














    }
}
