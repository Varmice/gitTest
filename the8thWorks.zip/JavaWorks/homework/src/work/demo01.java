package work;
//1000之内能被3整除的数的和
public class demo01 {
    public static void main(String[] args) {

        int sum = 0;

       for (int a = 0;a <= 1000;a++){
           if (a % 3 == 0){
               sum += a;

           }
       }
        System.out.println(sum);
    }
}
