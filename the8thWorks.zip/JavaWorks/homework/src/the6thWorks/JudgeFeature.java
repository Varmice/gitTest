package the6thWorks;
//判断输入三个面向对象编程特征的顺序是否正确
import java.util.Scanner;

public class JudgeFeature {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入三个面向对象编程的特征（用空格分隔）：");

        // 从用户获取输入
        String input = scanner.nextLine();
        scanner.close();

        // 分割用户输入为单词
        String[] features = input.split(" ");

        // 检查特征的顺序是否正确
        if (features.length != 3 || !isValidOrder(features)) {
            System.out.println("特征的顺序不正确！");
        } else {
            System.out.println("特征的顺序正确！");
        }
    }

    public static boolean isValidOrder(String[] features) {
        return features[0].equalsIgnoreCase("封装") &&
                features[1].equalsIgnoreCase("继承") &&
                features[2].equalsIgnoreCase("多态");
    }
}

