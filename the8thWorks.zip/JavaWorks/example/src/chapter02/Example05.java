package chapter02;

public class Example05 {
    public static void main(String[] args) {
        short s = 3;
        int i = 5;
        s += i;
        System.out.println("s = "+ s);
    }
}
