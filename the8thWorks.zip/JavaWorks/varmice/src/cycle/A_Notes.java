package cycle;

public class A_Notes {

    public static void main(String[] args) {
        // ctrl + alt+ l 格式化代码

        //x.fori 快速for循环
        /*例题：100.fori
        for (int i = 0; i < 100; i++) {

        }*/

        /*
            类使用方法
            1.导包  2.创建对象 3. 接收数据

         */







    }
}




