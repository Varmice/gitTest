package array;
//给数组赋上随机数，求和并统计个数
import java.util.Random;

public class Array05 {
    public static void main(String[] args) {
        Random r = new Random();
        //int num = r.nextInt();
        int[] arr = new int[10];
        int sum = 0;

        for (int i = 0; i < arr.length; i++) {
            int num = r.nextInt(10) + 1;

            arr[i] = num;
            sum += arr[i];
        }


        //遍历
        for (int i = 0; i < arr.length; i++) {

            System.out.println(arr[i]);

        }
        double ave = sum / arr.length;

        System.out.println("该数组的和为：" + sum);
        System.out.println("该数组的平均数为：" + ave);


    }
}


