package oop.test01;

public class StringTest {
    public static void main(String[] args) {

        String s = "skjfksjflsfjslfsl";
        System.out.println(s.length());
        System.out.println(s.toUpperCase());


    }//main
}
