package cycle;

import java.util.Random;
import java.util.Scanner;

public class A_Temp {
    public static void main(String[] args) {

        Random r = new Random();
        int i = r.nextInt( 1,100);
        System.out.println("随机数等于 " + i);
        //System.out.println("请输入一个 1 - 100 的整数");
        Scanner sc = new Scanner(System.in);


        while (true){
            System.out.println("请输入一个 1 - 100 的整数");
            int j = sc.nextInt();
            if (j > i){
                System.out.println("太大了");
            }
            else if (j < i){
                System.out.println("太小了");
            }
            else{
                System.out.println("恭喜你答对了");
                break;
            }
        }
    }
}
