package the8thWorks;
//throw的使用
public class Throw {
    public static void main(String[] args) {
        throw new RuntimeException("异常示例");
    }
}

