package the8thWorks;
//Try后不一定要跟throw或finally
public class Try {
    public static void main(String[] args) {
        try {
            int result = divide(10, 0);
            System.out.println("结果: " + result);
        } finally {
            System.out.println("这句话总会被执行，即使发生异常");
        }
    }

    public static int divide(int dividend, int divisor) {
        if (divisor == 0) {
            throw new ArithmeticException("除数不能为零");
        }
        return dividend / divisor;
    }
}

