package the8thWorks;
//输出abcdefg所有子串
public class SubstringDemo {
    public static void main(String[] args) {
        String input = "abcdefg";

        for (int i = 0; i < input.length(); i++) {
            for (int j = i + 1; j <= input.length(); j++) {
                String substring = input.substring(i, j);
                System.out.print(substring + "\t");
            }
            System.out.println();
        }
    }
}

