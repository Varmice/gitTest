package method;

import java.util.Scanner;

public class Method06 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入数组长度：");
        int length = sc.nextInt();
        int[] arr = new int[length];

        System.out.println("请输入数组数据：");
        for (int i = 0; i < arr.length; i++) {

            arr[i] = sc.nextInt();
            System.out.print(arr[i] + " ");
        }


    }
}
