package chapter02;

public class Example01 {

    public static void main(String[] args) {
        int num = 4;
//        byte b = num;
        byte b = (byte)num;
        System.out.println(b);
    }
}
