package the8thWorks;
//某物流公司车厢上写着“上海-南京-徐州-北京”，写程序输出这个车所经过的城市名称（输出一列）。
public class City {
    public static void main(String[] args) {
        String[] arr = {"上海","南京","徐州","北京"};
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }



    }//main
}
