package cycle;
//for循环求和
public class ForDome {
    public static void main(String[] args) {
        int sum = 0;
        //求1-100中的偶数和
        for (int i = 0; i <= 100;i++){
            if (i % 2 == 0){
                sum += i;
            }
        }
        System.out.println(sum);
    }
}

