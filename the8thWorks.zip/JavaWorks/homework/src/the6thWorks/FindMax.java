package the6thWorks;
//输入是个数据打印三个最大值
import java.util.Scanner;
import java.util.Arrays;

public class FindMax {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //System.out.println("请输入10个整数，用空格隔开：");
        int[] numbers = new int[10];

        for (int i = 0; i < 10; i++) {
            numbers[i] = scanner.nextInt();
        }

        Arrays.sort(numbers); // 对数组进行排序

        // 输出最大的三个数，以降序输出
        System.out.print(numbers[9] + " " + numbers[8] + " " + numbers[7]);

        scanner.close();
    }
}
